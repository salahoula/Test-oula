export class Post {
    constructor(
      public _id: string,
      public titre: string,
      public contenu: string
    ) {}
  }
  